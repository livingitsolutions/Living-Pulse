
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// db/acquisitionConsole.ts
import { count, eq } from "drizzle-orm";

// db/index.ts
import { drizzle } from "drizzle-orm/netlify-db";

// db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  acquisitionAuditEvents: () => acquisitionAuditEvents,
  acquisitionOutreachAttempts: () => acquisitionOutreachAttempts,
  acquisitionProspects: () => acquisitionProspects,
  acquisitionSuppressions: () => acquisitionSuppressions,
  counters: () => counters,
  events: () => events,
  feedback: () => feedback,
  operatorLoginAttempts: () => operatorLoginAttempts,
  operatorSessions: () => operatorSessions,
  productOperationIdempotency: () => productOperationIdempotency,
  pulses: () => pulses,
  responses: () => responses
});
import { sql } from "drizzle-orm";
import { boolean, check, index, integer, jsonb, pgTable, serial, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
var pulses = pgTable("pulses", {
  id: uuid("id").defaultRandom().primaryKey(),
  creatorKey: uuid("creator_key").defaultRandom().notNull(),
  businessName: text("business_name").notNull(),
  idea: text("idea").notNull(),
  question: text("question").notNull(),
  options: jsonb("options").$type().notNull(),
  followUp: jsonb("follow_up").$type(),
  allowUpdates: boolean("allow_updates").default(false).notNull(),
  status: text("status").default("Testing").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var responses = pgTable("responses", {
  id: serial("id").primaryKey(),
  pulseId: uuid("pulse_id").notNull().references(() => pulses.id, { onDelete: "cascade" }),
  optionId: text("option_id").notNull(),
  followUpOptionId: text("follow_up_option_id"),
  followUpText: text("follow_up_text"),
  email: text("email"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var events = pgTable("events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  pulseId: uuid("pulse_id"),
  sessionId: text("session_id"),
  metadata: jsonb("metadata").$type(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  pulseId: uuid("pulse_id").notNull().references(() => pulses.id, { onDelete: "cascade" }),
  decision: text("decision").notNull(),
  useful: text("useful").notNull(),
  affectedPlan: text("affected_plan").notNull(),
  useAgain: text("use_again").notNull(),
  worthPaying: text("worth_paying").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var counters = pgTable("counters", {
  id: serial("id").primaryKey(),
  value: integer("value").default(0).notNull()
});
var acquisitionProspects = pgTable("acquisition_prospects", {
  id: uuid("id").defaultRandom().primaryKey(),
  businessName: text("business_name").notNull(),
  websiteUrl: text("website_url"),
  publicContactEmail: text("public_contact_email").notNull(),
  normalizedEmail: text("normalized_email").notNull(),
  industry: text("industry"),
  locationText: text("location_text"),
  sourceUrl: text("source_url").notNull(),
  sourceType: text("source_type").notNull(),
  sourceObservedAt: timestamp("source_observed_at", { withTimezone: true }).notNull(),
  evidenceNote: text("evidence_note").notNull(),
  potentialUseCase: text("potential_use_case"),
  emailSourceUrl: text("email_source_url").notNull(),
  qualificationStatus: text("qualification_status").default("pending").notNull(),
  rejectionReason: text("rejection_reason"),
  outreachStatus: text("outreach_status").default("not_contacted").notNull(),
  personalizationContext: text("personalization_context"),
  personalizationEvidence: text("personalization_evidence"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  uniqueIndex("acquisition_prospects_normalized_email_unique").on(table.normalizedEmail),
  index("acquisition_prospects_outreach_status_idx").on(table.outreachStatus),
  check("acquisition_prospects_source_type_check", sql`${table.sourceType} in ('business_website', 'public_business_directory', 'public_social_business_page', 'manual')`),
  check("acquisition_prospects_qualification_status_check", sql`${table.qualificationStatus} in ('pending', 'qualified', 'rejected')`),
  check("acquisition_prospects_outreach_status_check", sql`${table.outreachStatus} in ('not_contacted', 'queued', 'sent', 'replied', 'converted', 'suppressed')`)
]);
var acquisitionSuppressions = pgTable("acquisition_suppressions", {
  normalizedEmail: text("normalized_email").primaryKey(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  index("acquisition_suppressions_email_idx").on(table.normalizedEmail),
  check("acquisition_suppressions_reason_check", sql`${table.reason} in ('unsubscribe', 'bounce', 'complaint', 'manual', 'invalid')`)
]);
var acquisitionOutreachAttempts = pgTable("acquisition_outreach_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  prospectId: uuid("prospect_id").notNull().references(() => acquisitionProspects.id, { onDelete: "cascade" }),
  sequenceNumber: integer("sequence_number").notNull(),
  status: text("status").default("queued").notNull(),
  scheduledFor: timestamp("scheduled_for", { withTimezone: true }),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  providerMessageId: text("provider_message_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  uniqueIndex("acquisition_attempts_prospect_sequence_unique").on(table.prospectId, table.sequenceNumber),
  index("acquisition_attempts_status_idx").on(table.status),
  check("acquisition_attempts_sequence_check", sql`${table.sequenceNumber} between 1 and 2`),
  check("acquisition_attempts_status_check", sql`${table.status} in ('queued', 'sent', 'cancelled')`)
]);
var acquisitionAuditEvents = pgTable("acquisition_audit_events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  prospectId: uuid("prospect_id").references(() => acquisitionProspects.id, { onDelete: "set null" }),
  attemptId: uuid("attempt_id").references(() => acquisitionOutreachAttempts.id, { onDelete: "set null" }),
  metadata: jsonb("metadata").$type(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  index("acquisition_audit_events_prospect_created_idx").on(table.prospectId, table.createdAt),
  check("acquisition_audit_events_name_check", sql`${table.name} in ('prospect_created', 'prospect_qualified', 'prospect_rejected', 'prospect_queued', 'prospect_suppressed', 'outreach_attempt_created', 'outreach_marked_sent', 'prospect_marked_replied', 'prospect_marked_converted')`)
]);
var operatorSessions = pgTable("operator_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true })
}, (table) => [
  index("operator_sessions_expires_at_idx").on(table.expiresAt)
]);
var operatorLoginAttempts = pgTable("operator_login_attempts", {
  id: serial("id").primaryKey(),
  clientHash: text("client_hash").notNull(),
  attemptedAt: timestamp("attempted_at", { withTimezone: true }).notNull()
}, (table) => [
  index("operator_login_attempts_client_time_idx").on(table.clientHash, table.attemptedAt)
]);
var productOperationIdempotency = pgTable("product_operation_idempotency", {
  id: uuid("id").defaultRandom().primaryKey(),
  operationScope: text("operation_scope").notNull(),
  idempotencyKeyHash: text("idempotency_key_hash").notNull(),
  requestFingerprint: text("request_fingerprint").notNull(),
  status: text("status").default("in_progress").notNull(),
  resourceType: text("resource_type"),
  resourceId: text("resource_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  uniqueIndex("product_idempotency_scope_key_unique").on(table.operationScope, table.idempotencyKeyHash),
  index("product_idempotency_created_at_idx").on(table.createdAt),
  check("product_idempotency_status_check", sql`${table.status} in ('in_progress', 'completed')`)
]);

// db/index.ts
var db = drizzle({ schema: schema_exports });

// db/acquisitionConsole.ts
var iso = (value) => value?.toISOString() ?? null;
var acquisitionConsoleRepository = {
  async listProspects() {
    const rows = await db.select({
      id: acquisitionProspects.id,
      businessName: acquisitionProspects.businessName,
      industry: acquisitionProspects.industry,
      locationText: acquisitionProspects.locationText,
      qualificationStatus: acquisitionProspects.qualificationStatus,
      outreachStatus: acquisitionProspects.outreachStatus,
      sourceType: acquisitionProspects.sourceType,
      attemptCount: count(acquisitionOutreachAttempts.id)
    }).from(acquisitionProspects).leftJoin(acquisitionOutreachAttempts, eq(acquisitionOutreachAttempts.prospectId, acquisitionProspects.id)).groupBy(acquisitionProspects.id).orderBy(acquisitionProspects.createdAt);
    return rows.map((row) => ({ ...row, qualificationStatus: row.qualificationStatus, outreachStatus: row.outreachStatus, sourceType: row.sourceType }));
  },
  async findProspect(id) {
    const [prospect] = await db.select().from(acquisitionProspects).where(eq(acquisitionProspects.id, id)).limit(1);
    if (!prospect) return null;
    const attempts = await db.select().from(acquisitionOutreachAttempts).where(eq(acquisitionOutreachAttempts.prospectId, id)).orderBy(acquisitionOutreachAttempts.sequenceNumber);
    const [suppression] = await db.select().from(acquisitionSuppressions).where(eq(acquisitionSuppressions.normalizedEmail, prospect.normalizedEmail)).limit(1);
    const attemptRows = attempts.map((attempt) => ({ id: attempt.id, businessName: prospect.businessName, prospectId: id, sequenceNumber: attempt.sequenceNumber, status: attempt.status, outreachStatus: prospect.outreachStatus, scheduledFor: iso(attempt.scheduledFor), sentAt: iso(attempt.sentAt) }));
    const suppressionRow = suppression ? { businessName: prospect.businessName, prospectId: id, reason: suppression.reason, createdAt: suppression.createdAt.toISOString() } : null;
    const attemptCount = attempts.length;
    return {
      id,
      businessName: prospect.businessName,
      websiteUrl: prospect.websiteUrl,
      publicContactEmail: prospect.publicContactEmail,
      industry: prospect.industry,
      locationText: prospect.locationText,
      sourceUrl: prospect.sourceUrl,
      sourceType: prospect.sourceType,
      sourceObservedAt: prospect.sourceObservedAt.toISOString(),
      evidenceNote: prospect.evidenceNote,
      potentialUseCase: prospect.potentialUseCase,
      emailSourceUrl: prospect.emailSourceUrl,
      personalizationContext: prospect.personalizationContext,
      personalizationEvidence: prospect.personalizationEvidence,
      qualificationStatus: prospect.qualificationStatus,
      rejectionReason: prospect.rejectionReason,
      outreachStatus: prospect.outreachStatus,
      attemptCount,
      suppression: suppressionRow,
      attempts: attemptRows,
      safety: {
        publicSourceEvidence: /^https?:\/\//.test(prospect.sourceUrl),
        validPublicEmail: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(prospect.normalizedEmail),
        qualified: prospect.qualificationStatus === "qualified",
        notSuppressed: !suppression && prospect.outreachStatus !== "suppressed",
        attemptCapacity: attemptCount < 2
      }
    };
  },
  async listAttempts() {
    const rows = await db.select({ attempt: acquisitionOutreachAttempts, businessName: acquisitionProspects.businessName, outreachStatus: acquisitionProspects.outreachStatus }).from(acquisitionOutreachAttempts).innerJoin(acquisitionProspects, eq(acquisitionProspects.id, acquisitionOutreachAttempts.prospectId)).orderBy(acquisitionOutreachAttempts.createdAt);
    return rows.map(({ attempt, businessName, outreachStatus }) => ({ id: attempt.id, businessName, prospectId: attempt.prospectId, sequenceNumber: attempt.sequenceNumber, status: attempt.status, outreachStatus, scheduledFor: iso(attempt.scheduledFor), sentAt: iso(attempt.sentAt) }));
  },
  async listSuppressions() {
    const rows = await db.select({ suppression: acquisitionSuppressions, prospectId: acquisitionProspects.id, businessName: acquisitionProspects.businessName }).from(acquisitionSuppressions).leftJoin(acquisitionProspects, eq(acquisitionProspects.normalizedEmail, acquisitionSuppressions.normalizedEmail)).orderBy(acquisitionSuppressions.createdAt);
    return rows.map(({ suppression, prospectId, businessName }) => ({ businessName, prospectId, reason: suppression.reason, createdAt: suppression.createdAt.toISOString() }));
  }
};

// db/prospectStore.ts
import { and, count as count2, eq as eq2, sql as sql2 } from "drizzle-orm";
var stored = (row) => ({
  id: row.id,
  businessName: row.businessName,
  websiteUrl: row.websiteUrl,
  publicContactEmail: row.publicContactEmail,
  normalizedEmail: row.normalizedEmail,
  industry: row.industry,
  locationText: row.locationText,
  sourceUrl: row.sourceUrl,
  sourceType: row.sourceType,
  sourceObservedAt: row.sourceObservedAt,
  evidenceNote: row.evidenceNote,
  potentialUseCase: row.potentialUseCase,
  emailSourceUrl: row.emailSourceUrl,
  qualificationStatus: row.qualificationStatus,
  rejectionReason: row.rejectionReason,
  outreachStatus: row.outreachStatus,
  personalizationContext: row.personalizationContext,
  personalizationEvidence: row.personalizationEvidence
});
function transactionAdapter(tx) {
  return {
    async findProspect(id) {
      const [row] = await tx.select().from(acquisitionProspects).where(eq2(acquisitionProspects.id, id)).limit(1).for("update");
      return row ? stored(row) : null;
    },
    async findProspectByEmail(normalizedEmail) {
      const [row] = await tx.select().from(acquisitionProspects).where(eq2(acquisitionProspects.normalizedEmail, normalizedEmail)).limit(1);
      return row ? stored(row) : null;
    },
    async findProspectByWebsite(domain) {
      const [row] = await tx.select().from(acquisitionProspects).where(sql2`lower(regexp_replace(split_part(${acquisitionProspects.websiteUrl}, '://', 2), '^www\\.', '')) LIKE ${domain + "%"}`).limit(1);
      return row ? stored(row) : null;
    },
    async findProspectByIdentity(identity) {
      const [name, location] = identity.split("|");
      const rows = await tx.select().from(acquisitionProspects).where(sql2`lower(regexp_replace(${acquisitionProspects.businessName}, '[^a-zA-Z0-9]+', ' ', 'g')) = ${name}`);
      const row = rows.find((item) => (item.locationText || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim() === location);
      return row ? stored(row) : null;
    },
    async insertProspect(prospect) {
      const [row] = await tx.insert(acquisitionProspects).values({ ...prospect, id: void 0 }).returning();
      return stored(row);
    },
    async updateProspect(id, changes) {
      const [row] = await tx.update(acquisitionProspects).set({
        qualificationStatus: changes.qualificationStatus,
        rejectionReason: changes.rejectionReason,
        outreachStatus: changes.outreachStatus,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq2(acquisitionProspects.id, id)).returning();
      return stored(row);
    },
    async isSuppressed(normalizedEmail) {
      const [row] = await tx.select({ normalizedEmail: acquisitionSuppressions.normalizedEmail }).from(acquisitionSuppressions).where(eq2(acquisitionSuppressions.normalizedEmail, normalizedEmail)).limit(1);
      return Boolean(row);
    },
    async insertSuppression(normalizedEmail, reason) {
      const rows = await tx.insert(acquisitionSuppressions).values({ normalizedEmail, reason }).onConflictDoNothing().returning({ normalizedEmail: acquisitionSuppressions.normalizedEmail });
      return rows.length === 1;
    },
    async countAttempts(prospectId) {
      const [row] = await tx.select({ value: count2() }).from(acquisitionOutreachAttempts).where(eq2(acquisitionOutreachAttempts.prospectId, prospectId));
      return row.value;
    },
    async insertAttempt(prospectId, sequenceNumber) {
      const [row] = await tx.insert(acquisitionOutreachAttempts).values({ prospectId, sequenceNumber, status: "queued" }).returning({ id: acquisitionOutreachAttempts.id });
      return row;
    },
    async insertAudit(name, prospectId, attemptId, metadata) {
      await tx.insert(acquisitionAuditEvents).values({ name, prospectId, attemptId, metadata });
    }
  };
}
var prospectStore = {
  transaction: (operation) => db.transaction((tx) => operation(transactionAdapter(tx))),
  async findProspectByEmail(normalizedEmail) {
    const [row] = await db.select().from(acquisitionProspects).where(and(eq2(acquisitionProspects.normalizedEmail, normalizedEmail))).limit(1);
    return row ? stored(row) : null;
  },
  async findProspectByWebsite(domain) {
    const [row] = await db.select().from(acquisitionProspects).where(sql2`lower(regexp_replace(split_part(${acquisitionProspects.websiteUrl}, '://', 2), '^www\\.', '')) LIKE ${domain + "%"}`).limit(1);
    return row ? stored(row) : null;
  },
  async findProspectByIdentity(identity) {
    const [name, location] = identity.split("|");
    const rows = await db.select().from(acquisitionProspects).where(sql2`lower(regexp_replace(${acquisitionProspects.businessName}, '[^a-zA-Z0-9]+', ' ', 'g')) = ${name}`);
    const row = rows.find((item) => (item.locationText || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim() === location);
    return row ? stored(row) : null;
  },
  async isSuppressed(normalizedEmail) {
    const [row] = await db.select().from(acquisitionSuppressions).where(eq2(acquisitionSuppressions.normalizedEmail, normalizedEmail)).limit(1);
    return Boolean(row);
  }
};

// src/acquisitionFoundation.ts
var MAX_OUTREACH_ATTEMPTS = 2;
var INITIAL_DAILY_SEND_LIMIT = 10;
var SOURCE_TYPES = ["business_website", "public_business_directory", "public_social_business_page", "manual"];
var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var transitions = {
  not_contacted: ["queued", "suppressed"],
  queued: ["sent", "suppressed"],
  sent: ["replied", "suppressed"],
  replied: ["converted", "suppressed"],
  converted: ["suppressed"],
  suppressed: []
};
function normalizeEmail(email) {
  return email.trim().toLowerCase();
}
function createProspect(input) {
  const normalizedEmail = normalizeEmail(input.publicContactEmail);
  if (!input.businessName.trim()) throw new Error("Business name is required.");
  if (!SOURCE_TYPES.includes(input.sourceType)) throw new Error("A valid source type is required.");
  if (!emailPattern.test(normalizedEmail)) throw new Error("A valid publicly listed business email is required.");
  if (!isPublicSourceUrl(input.sourceUrl) || !input.sourceObservedAt || Number.isNaN(input.sourceObservedAt.getTime())) throw new Error("Public source evidence is required.");
  if (!input.evidenceNote?.trim()) throw new Error("A concise public-source evidence note is required.");
  if (!isPublicSourceUrl(input.emailSourceUrl)) throw new Error("Public email source evidence is required.");
  if (input.personalizationContext?.trim() && !input.personalizationEvidence?.trim()) throw new Error("Personalization facts require public evidence.");
  const optional = (value) => value?.trim() || null;
  return { ...input, businessName: input.businessName.trim(), websiteUrl: optional(input.websiteUrl), industry: optional(input.industry), locationText: optional(input.locationText), publicContactEmail: input.publicContactEmail.trim(), normalizedEmail, sourceUrl: input.sourceUrl.trim(), emailSourceUrl: input.emailSourceUrl.trim(), evidenceNote: input.evidenceNote.trim(), potentialUseCase: optional(input.potentialUseCase), personalizationContext: optional(input.personalizationContext), personalizationEvidence: optional(input.personalizationEvidence), qualificationStatus: "pending", rejectionReason: null, outreachStatus: "not_contacted" };
}
function normalizeWebsite(value) {
  if (!value) return null;
  try {
    const url = new URL(value);
    return url.hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return null;
  }
}
function normalizeBusinessIdentity(name, location) {
  return `${name.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()}|${(location || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()}`;
}
function isPublicSourceUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}
function assertEmailAvailable(normalizedEmail, existingNormalizedEmails) {
  if (existingNormalizedEmails.some((email) => normalizeEmail(email) === normalizeEmail(normalizedEmail))) throw new Error("A prospect with this public email already exists.");
}
function qualify(current) {
  if (current !== "pending") throw new Error("Invalid qualification transition.");
  return "qualified";
}
function reject(current, reason) {
  if (current !== "pending" || !reason.trim()) throw new Error("Invalid qualification transition or rejection reason.");
  return { qualificationStatus: "rejected", rejectionReason: reason.trim() };
}
function assertQueueEligible(prospect, suppressed, attemptCount) {
  if (suppressed || prospect.outreachStatus === "suppressed") throw new Error("Suppressed addresses cannot be queued.");
  if (prospect.qualificationStatus !== "qualified") throw new Error("Only qualified prospects can be queued.");
  if (!isPublicSourceUrl(prospect.sourceUrl) || !prospect.sourceObservedAt || Number.isNaN(prospect.sourceObservedAt.getTime()) || !emailPattern.test(prospect.normalizedEmail)) throw new Error("Valid public source evidence and email are required.");
  if (attemptCount >= MAX_OUTREACH_ATTEMPTS) throw new Error("Maximum outreach attempts reached.");
  if (attemptCount !== 0) throw new Error("Initial outreach attempt already exists.");
  if (prospect.outreachStatus !== "not_contacted") throw new Error("Prospect is already active or cannot be queued.");
}
function transitionOutreach(current, next) {
  if (!transitions[current].includes(next)) throw new Error(`Invalid outreach transition: ${current} -> ${next}`);
  return next;
}
function addSuppression(email, reason) {
  const normalizedEmail = normalizeEmail(email);
  if (!emailPattern.test(normalizedEmail)) throw new Error("A valid email is required for suppression.");
  return { normalizedEmail, reason };
}

// src/prospectServices.ts
function requiredProspect(value) {
  if (!value) throw new Error("Prospect not found.");
  return value;
}
function createProspectServices(store) {
  async function assertIntakeAvailable(prospect) {
    assertEmailAvailable(prospect.normalizedEmail, await store.findProspectByEmail(prospect.normalizedEmail) ? [prospect.normalizedEmail] : []);
    if (await store.isSuppressed(prospect.normalizedEmail)) throw new Error("This public email is suppressed and cannot be imported.");
    const domain = normalizeWebsite(prospect.websiteUrl);
    if (domain && await store.findProspectByWebsite(domain)) throw new Error("A prospect with this website already exists.");
    if (await store.findProspectByIdentity(normalizeBusinessIdentity(prospect.businessName, prospect.locationText))) throw new Error("A prospect with this business identity already exists; review it manually.");
  }
  return {
    async validateCreate(input) {
      const prospect = createProspect(input);
      await assertIntakeAvailable(prospect);
      return prospect;
    },
    async createProspect(input) {
      const prospect = createProspect(input);
      await assertIntakeAvailable(prospect);
      return store.transaction(async (tx) => {
        assertEmailAvailable(prospect.normalizedEmail, await tx.findProspectByEmail(prospect.normalizedEmail) ? [prospect.normalizedEmail] : []);
        if (await tx.isSuppressed(prospect.normalizedEmail)) throw new Error("This public email is suppressed and cannot be imported.");
        const domain = normalizeWebsite(prospect.websiteUrl);
        if (domain && await tx.findProspectByWebsite(domain)) throw new Error("A prospect with this website already exists.");
        if (await tx.findProspectByIdentity(normalizeBusinessIdentity(prospect.businessName, prospect.locationText))) throw new Error("A prospect with this business identity already exists; review it manually.");
        const saved = await tx.insertProspect(prospect);
        await tx.insertAudit("prospect_created", saved.id, void 0, { intake: "discovery", initiatedBy: "authenticated_operator" });
        return saved;
      });
    },
    async qualifyProspect(id) {
      return store.transaction(async (tx) => {
        const prospect = requiredProspect(await tx.findProspect(id));
        const saved = await tx.updateProspect(id, { qualificationStatus: qualify(prospect.qualificationStatus), rejectionReason: null });
        await tx.insertAudit("prospect_qualified", id);
        return saved;
      });
    },
    async rejectProspect(id, reason) {
      return store.transaction(async (tx) => {
        const prospect = requiredProspect(await tx.findProspect(id));
        const outcome = reject(prospect.qualificationStatus, reason);
        const saved = await tx.updateProspect(id, outcome);
        await tx.insertAudit("prospect_rejected", id, void 0, { reason: outcome.rejectionReason });
        return saved;
      });
    },
    async suppressProspect(id, reason) {
      return store.transaction(async (tx) => {
        const prospect = requiredProspect(await tx.findProspect(id));
        const suppression = addSuppression(prospect.normalizedEmail, reason);
        const created = await tx.insertSuppression(suppression.normalizedEmail, suppression.reason);
        const saved = prospect.outreachStatus === "suppressed" ? prospect : await tx.updateProspect(id, { outreachStatus: transitionOutreach(prospect.outreachStatus, "suppressed") });
        if (created || prospect.outreachStatus !== "suppressed") await tx.insertAudit("prospect_suppressed", id, void 0, { reason });
        return saved;
      });
    },
    async queueProspect(id) {
      return store.transaction(async (tx) => {
        const prospect = requiredProspect(await tx.findProspect(id));
        const attemptCount = await tx.countAttempts(id);
        assertQueueEligible(prospect, await tx.isSuppressed(normalizeEmail(prospect.normalizedEmail)), attemptCount);
        const saved = await tx.updateProspect(id, { outreachStatus: transitionOutreach(prospect.outreachStatus, "queued") });
        const attempt = await tx.insertAttempt(id, 1);
        await tx.insertAudit("prospect_queued", id);
        await tx.insertAudit("outreach_attempt_created", id, attempt.id, { sequenceNumber: 1 });
        return { prospect: saved, attempt };
      });
    }
  };
}

// db/acquisitionApplication.ts
var { createProspect: createProspect2, qualifyProspect, rejectProspect, suppressProspect, queueProspect, validateCreate } = createProspectServices(prospectStore);

// db/operatorAuth.ts
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
var OPERATOR_COOKIE_NAME = "living_pulse_operator";
var SESSION_DURATION_MS = 12 * 60 * 60 * 1e3;
var LOGIN_WINDOW_MS = 15 * 60 * 1e3;
var MAX_LOGIN_FAILURES = 5;
var digest = (value) => createHash("sha256").update(value, "utf8").digest();
var hashOpaqueValue = (value) => digest(value).toString("hex");
function credentialMatches(credential, configuredSecret) {
  if (!configuredSecret || !credential) return false;
  return timingSafeEqual(digest(credential), digest(configuredSecret));
}
function cookieToken(request) {
  const header = request.headers.get("cookie") || "";
  for (const part of header.split(";")) {
    const [name, ...value] = part.trim().split("=");
    if (name === OPERATOR_COOKIE_NAME) return value.join("=") || null;
  }
  return null;
}
function validMutationOrigin(request) {
  const origin = request.headers.get("origin");
  return Boolean(origin && origin === new URL(request.url).origin);
}
var sessionCookie = (token, maxAge, secure) => {
  const attributes = [`${OPERATOR_COOKIE_NAME}=${token}`, "Path=/api/operator", `Max-Age=${maxAge}`, "HttpOnly", "SameSite=Strict"];
  if (secure) attributes.push("Secure");
  return attributes.join("; ");
};
var response = (body, status = 200, cookie) => Response.json(body, {
  status,
  headers: cookie ? { "Set-Cookie": cookie } : void 0
});
var failure = (status = 401) => response({ authenticated: false }, status);
function createOperatorAuthHandler(dependencies) {
  const now = dependencies.now || (() => /* @__PURE__ */ new Date());
  const randomToken = dependencies.randomToken || (() => randomBytes(32).toString("base64url"));
  async function authenticated(request) {
    const token = cookieToken(request);
    return token ? dependencies.store.findActiveSession(hashOpaqueValue(token), now()) : false;
  }
  return async (request, clientAddress) => {
    const url = new URL(request.url);
    const route = url.pathname.replace(/^\/api\/operator\/?/, "");
    const secure = url.protocol === "https:";
    if (request.method === "POST" && (route === "login" || route === "logout") && !validMutationOrigin(request)) {
      return failure(403);
    }
    if (request.method === "POST" && route === "login") {
      let body;
      try {
        body = await request.json();
      } catch {
        return failure();
      }
      const credential = typeof body === "object" && body !== null ? body.credential : void 0;
      if (typeof credential !== "string" || credential.trim().length === 0 || credential.length > 4096) return failure();
      const clientHash = hashOpaqueValue(clientAddress || "unknown-client");
      const current = now();
      const since = new Date(current.getTime() - LOGIN_WINDOW_MS);
      if (await dependencies.store.countRecentFailures(clientHash, since) >= MAX_LOGIN_FAILURES) return failure(429);
      if (!credentialMatches(credential, dependencies.secret())) {
        await dependencies.store.recordFailure(clientHash, current);
        return failure();
      }
      await dependencies.store.clearFailures(clientHash);
      const token = randomToken();
      await dependencies.store.createSession({
        tokenHash: hashOpaqueValue(token),
        createdAt: current,
        expiresAt: new Date(current.getTime() + SESSION_DURATION_MS),
        revokedAt: null
      });
      return response({ authenticated: true }, 200, sessionCookie(token, SESSION_DURATION_MS / 1e3, secure));
    }
    if (request.method === "GET" && route === "session") {
      return response({ authenticated: await authenticated(request) });
    }
    if (request.method === "POST" && route === "logout") {
      const token = cookieToken(request);
      if (token) await dependencies.store.revokeSession(hashOpaqueValue(token), now());
      return response({ authenticated: false }, 200, sessionCookie("", 0, secure));
    }
    if (request.method === "GET" && route === "protected-check") {
      return await authenticated(request) ? response({ authenticated: true }) : failure();
    }
    return Response.json({ error: "Not found" }, { status: 404 });
  };
}
async function hasOperatorSession(request, store, now = /* @__PURE__ */ new Date()) {
  const token = cookieToken(request);
  return token ? store.findActiveSession(hashOpaqueValue(token), now) : false;
}

// src/prospectDiscovery.ts
var MAX_DISCOVERY_RESULTS = 10;
var DISCOVERY_TIMEOUT_MS = 8e3;
var MAX_TEXT = 2e3;
var MAX_EVIDENCE_EXCERPT = 1e3;
var DiscoveryProviderUnavailableError = class extends Error {
  constructor() {
    super("Live public discovery is not configured. A supported public-web search provider and credential are required.");
  }
};
function bounded(value, label, required = false, maximum = MAX_TEXT) {
  if (value == null && !required) return "";
  if (typeof value !== "string" || required && !value.trim() || value.length > maximum) throw new Error(`${label} is invalid or exceeds the allowed length.`);
  return value.trim();
}
function unsafeHostname(hostname) {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
  if (host === "::1" || host === "::" || host.startsWith("fe80:") || host.startsWith("fc") || host.startsWith("fd")) return true;
  const parts = host.split(".").map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  const [a, b] = parts;
  return a === 0 || a === 10 || a === 127 || a === 169 && b === 254 || a === 172 && b >= 16 && b <= 31 || a === 192 && b === 168 || a >= 224;
}
function isSafePublicUrl(value) {
  try {
    const url = new URL(value);
    return (url.protocol === "http:" || url.protocol === "https:") && !url.username && !url.password && Boolean(url.hostname) && !unsafeHostname(url.hostname);
  } catch {
    return false;
  }
}
function validateDiscoveryCriteria(value) {
  if (!value || typeof value !== "object") throw new Error("Discovery criteria are required.");
  const criteria = value;
  const category = bounded(criteria.category, "Business category", true, 120);
  const location = bounded(criteria.location, "Location", true, 160);
  const maxResults = criteria.maxResults;
  if (!Number.isInteger(maxResults) || maxResults < 1 || maxResults > MAX_DISCOVERY_RESULTS) throw new Error("Maximum results must be an integer from 1 to 10.");
  return { category, location, maxResults };
}
function validateDiscoveryCandidate(value) {
  if (!value || typeof value !== "object") throw new Error("Malformed discovery candidate.");
  const businessName = bounded(value.businessName, "Business name", true, 240);
  if (!SOURCE_TYPES.includes(value.sourceType) || !["business_website", "public_business_directory", "public_social_business_page"].includes(value.sourceType)) throw new Error("A valid public source type is required.");
  if (!isSafePublicUrl(value.sourceUrl)) throw new Error("A safe public HTTP(S) source URL is required.");
  const evidenceNote = bounded(value.evidenceNote, "Public-source evidence note", true);
  if (!value.sourceObservedAt || Number.isNaN(new Date(value.sourceObservedAt).getTime())) throw new Error("A valid source observed timestamp is required.");
  const email = bounded(value.publicEmailEvidence?.email, "Observed public business email", true, 320);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("An observed public business email is required for acquisition intake.");
  if (!isSafePublicUrl(value.publicEmailEvidence?.sourceUrl)) throw new Error("A safe public HTTP(S) source supporting the public email is required.");
  const observedText = bounded(value.publicEmailEvidence?.observedText, "Email evidence excerpt", true, MAX_EVIDENCE_EXCERPT);
  if (!observedText.toLocaleLowerCase("en-US").includes(email.toLocaleLowerCase("en-US"))) throw new Error("Email evidence must contain the exact observed address; guessed emails are not accepted.");
  if (value.websiteUrl && !isSafePublicUrl(value.websiteUrl)) throw new Error("Website URL must be a safe public HTTP(S) URL.");
  if (value.personalizationEvidence && !isSafePublicUrl(value.personalizationEvidence)) throw new Error("Personalization evidence must use a safe public HTTP(S) URL.");
  if (value.personalizationContext?.trim() && !value.personalizationEvidence) throw new Error("Personalization requires a safe public HTTP(S) evidence URL.");
  return {
    ...value,
    businessName,
    industry: bounded(value.industry, "Industry", false, 240) || null,
    locationText: bounded(value.locationText, "Location", false, 320) || null,
    evidenceNote,
    potentialUseCase: bounded(value.potentialUseCase, "Potential use case") || null,
    personalizationContext: bounded(value.personalizationContext, "Personalization context") || null,
    websiteUrl: value.websiteUrl?.trim() || null,
    sourceUrl: value.sourceUrl.trim(),
    personalizationEvidence: value.personalizationEvidence?.trim() || null,
    publicEmailEvidence: { email, sourceUrl: value.publicEmailEvidence.sourceUrl.trim(), observedText }
  };
}
function candidateToProspectInput(candidate) {
  const valid = validateDiscoveryCandidate(candidate);
  return {
    businessName: valid.businessName,
    websiteUrl: valid.websiteUrl,
    publicContactEmail: valid.publicEmailEvidence.email,
    emailSourceUrl: valid.publicEmailEvidence.sourceUrl,
    sourceUrl: valid.sourceUrl,
    sourceType: valid.sourceType,
    sourceObservedAt: new Date(valid.sourceObservedAt),
    evidenceNote: `${valid.evidenceNote}
Email evidence excerpt: ${valid.publicEmailEvidence.observedText}`,
    potentialUseCase: valid.potentialUseCase,
    personalizationContext: valid.personalizationContext ?? null,
    personalizationEvidence: valid.personalizationEvidence ?? null,
    industry: valid.industry,
    locationText: valid.locationText
  };
}
async function runDiscovery(provider, rawCriteria) {
  const criteria = validateDiscoveryCriteria(rawCriteria);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), DISCOVERY_TIMEOUT_MS);
  try {
    const timeout = new Promise((_, reject2) => controller.signal.addEventListener("abort", () => reject2(new Error("Discovery provider timed out safely.")), { once: true }));
    const candidates = await Promise.race([provider.discover(criteria, controller.signal), timeout]);
    if (!Array.isArray(candidates)) throw new Error("Discovery provider returned a malformed response.");
    return candidates.slice(0, criteria.maxResults).map(validateDiscoveryCandidate);
  } finally {
    clearTimeout(timer);
  }
}

// db/operatorConsole.ts
var suppressionReasons = ["manual", "unsubscribe", "bounce", "complaint", "invalid"];
var json = (body, status = 200) => Response.json(body, { status });
var safeFailure = (message = "The request could not be completed.", status = 409) => json({ error: message }, status);
function logFailure(classification) {
  console.error("Growth operator request failed", { classification });
}
function createOperatorConsoleHandler(dependencies) {
  return async (request) => {
    if (!await dependencies.authenticated(request)) return json({ error: "Authentication required" }, 401);
    const parts = new URL(request.url).pathname.replace(/^\/api\/operator\/?/, "").split("/").filter(Boolean);
    if (request.method === "POST" && !validMutationOrigin(request)) return json({ error: "Request origin rejected" }, 403);
    try {
      if (request.method === "POST" && parts.join("/") === "prospects/discover") {
        try {
          const body = await request.json();
          const discovered = await runDiscovery(dependencies.discoveryProvider, body.criteria);
          const candidates = await Promise.all(discovered.map(async (candidate) => ({ ...candidate, existingProspect: await dependencies.prospectExistsByEmail(normalizeEmail(candidate.publicEmailEvidence.email)) })));
          return json({ provider: dependencies.discoveryProvider.id, candidates });
        } catch (error2) {
          const unavailable = error2 instanceof DiscoveryProviderUnavailableError;
          logFailure(unavailable ? "discovery_provider_unavailable" : "discovery_internal");
          return safeFailure("Discovery could not be completed.", unavailable ? 503 : 409);
        }
      }
      if (request.method === "POST" && parts.join("/") === "prospects/import") {
        const body = await request.json();
        if (!body.candidate) return json({ error: "A confirmed discovery candidate is required." }, 400);
        const prospect = await dependencies.services.createProspect(candidateToProspectInput(body.candidate));
        return json({ prospect }, 201);
      }
      if (request.method === "GET" && parts.join("/") === "acquisition/overview") {
        const prospects = await dependencies.repository.listProspects();
        const overview = {
          total: prospects.length,
          pending: prospects.filter((item) => item.qualificationStatus === "pending").length,
          qualified: prospects.filter((item) => item.qualificationStatus === "qualified").length,
          queued: prospects.filter((item) => item.outreachStatus === "queued").length,
          sent: prospects.filter((item) => item.outreachStatus === "sent").length,
          replied: prospects.filter((item) => item.outreachStatus === "replied").length,
          converted: prospects.filter((item) => item.outreachStatus === "converted").length,
          suppressed: prospects.filter((item) => item.outreachStatus === "suppressed").length,
          policy: { sendingEnabled: false, dailyLimit: INITIAL_DAILY_SEND_LIMIT, maximumAttempts: MAX_OUTREACH_ATTEMPTS }
        };
        return json(overview);
      }
      if (request.method === "GET" && parts.length === 1 && parts[0] === "prospects") return json(await dependencies.repository.listProspects());
      if (request.method === "GET" && parts.join("/") === "outreach") return json(await dependencies.repository.listAttempts());
      if (request.method === "GET" && parts.join("/") === "suppressions") return json(await dependencies.repository.listSuppressions());
      if (parts[0] === "prospects" && parts[1]) {
        const id = parts[1];
        if (request.method === "GET" && parts.length === 2) {
          const prospect = await dependencies.repository.findProspect(id);
          return prospect ? json(prospect) : json({ error: "Prospect not found" }, 404);
        }
        if (request.method === "POST" && parts.length === 3) {
          let body = {};
          try {
            body = await request.json();
          } catch {
          }
          if (parts[2] === "qualify") await dependencies.services.qualifyProspect(id);
          else if (parts[2] === "reject") await dependencies.services.rejectProspect(id, typeof body.reason === "string" ? body.reason : "");
          else if (parts[2] === "suppress") {
            if (!suppressionReasons.includes(body.reason)) return json({ error: "A valid suppression reason is required" }, 400);
            await dependencies.services.suppressProspect(id, body.reason);
          } else if (parts[2] === "queue") await dependencies.services.queueProspect(id);
          else return json({ error: "Not found" }, 404);
          return json({ ok: true });
        }
      }
      return json({ error: "Not found" }, 404);
    } catch {
      logFailure("operator_request_rejected");
      return safeFailure();
    }
  };
}

// db/operatorStore.ts
import { and as and2, count as count3, eq as eq3, gt, isNull } from "drizzle-orm";
var operatorStore = {
  async createSession(session) {
    await db.insert(operatorSessions).values(session);
  },
  async findActiveSession(tokenHash, now) {
    const [row] = await db.select({ tokenHash: operatorSessions.tokenHash }).from(operatorSessions).where(and2(eq3(operatorSessions.tokenHash, tokenHash), isNull(operatorSessions.revokedAt), gt(operatorSessions.expiresAt, now))).limit(1);
    return Boolean(row);
  },
  async revokeSession(tokenHash, now) {
    await db.update(operatorSessions).set({ revokedAt: now }).where(and2(eq3(operatorSessions.tokenHash, tokenHash), isNull(operatorSessions.revokedAt)));
  },
  async countRecentFailures(clientHash, since) {
    const [row] = await db.select({ value: count3() }).from(operatorLoginAttempts).where(and2(eq3(operatorLoginAttempts.clientHash, clientHash), gt(operatorLoginAttempts.attemptedAt, since)));
    return row.value;
  },
  async recordFailure(clientHash, attemptedAt) {
    await db.insert(operatorLoginAttempts).values({ clientHash, attemptedAt });
  },
  async clearFailures(clientHash) {
    await db.delete(operatorLoginAttempts).where(eq3(operatorLoginAttempts.clientHash, clientHash));
  }
};

// db/productOperationRepository.ts
import { and as and3, count as count4, eq as eq4 } from "drizzle-orm";

// server/productOperations.ts
import { createHash as createHash2 } from "node:crypto";

// src/acquisition.ts
var uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function parseAttribution(value) {
  if (!value || typeof value !== "object") return null;
  const candidate = value;
  if (candidate.source !== "powered_by" || typeof candidate.sourcePulseId !== "string" || !uuidPattern.test(candidate.sourcePulseId)) return null;
  return { source: "powered_by", sourcePulseId: candidate.sourcePulseId };
}

// src/validation.ts
var WRITTEN_FEEDBACK_MAX_LENGTH = 1e3;
function writtenFeedbackValue(value) {
  if (typeof value !== "string") return { value: null, valid: true };
  const trimmed = value.trim();
  if (!trimmed) return { value: null, valid: true };
  return { value: trimmed, valid: trimmed.length <= WRITTEN_FEEDBACK_MAX_LENGTH };
}
function isWrittenFollowUp(followUp) {
  return followUp?.type === "written_feedback";
}
function hasWrittenFeedbackQuestion(value) {
  return typeof value === "string" && value.trim().length > 0;
}
function collectWrittenFeedback(rows) {
  return rows.flatMap((row) => row.followUpText ? [row.followUpText] : []);
}

// server/productOperations.ts
var PRODUCT_STATUSES = ["Draft", "Testing", "Planned", "Coming Soon", "Launched", "Archived"];
var PRODUCT_EVENT_NAMES = ["landing_viewed", "create_started", "pulse_created", "pulse_published", "pulse_link_copied", "qr_downloaded", "public_pulse_viewed", "response_started", "response_completed", "update_opt_in", "results_viewed", "second_pulse_created", "powered_by_clicked"];
var ProductOperationError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
  status;
};
var clean = (value, max = 500) => typeof value === "string" ? value.trim().slice(0, max) : "";
var hash = (value) => createHash2("sha256").update(value, "utf8").digest("hex");
function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value && typeof value === "object") {
    const entries = Object.entries(value).filter(([, item]) => item !== void 0).sort(([a], [b]) => a.localeCompare(b));
    return `{${entries.map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
var hashIdempotencyKey = (key) => hash(key);
var requestFingerprint = (value) => hash(canonical(value));
function idempotency(key, operationScope, logicalRequest) {
  if (!key) throw new ProductOperationError("An idempotency key is required.", 400);
  return { operationScope, idempotencyKeyHash: hashIdempotencyKey(key), requestFingerprint: requestFingerprint(logicalRequest) };
}
function normalizePulse(body) {
  const options = Array.isArray(body.options) ? body.options.map((option) => ({ id: clean(option.id, 80), label: clean(option.label, 120) })).filter((option) => option.id && option.label) : [];
  const businessName = clean(body.businessName, 120);
  const idea = clean(body.idea, 160);
  const question = clean(body.question, 300);
  if (!businessName || !idea || !question || options.length < 2) throw new ProductOperationError("Business name, idea, question, and at least two options are required.", 400);
  let followUp = null;
  if (body.followUp && typeof body.followUp === "object") {
    const raw = body.followUp;
    const followQuestion = clean(raw.question, 300);
    if (raw.type === "written_feedback") {
      if (!hasWrittenFeedbackQuestion(followQuestion)) throw new ProductOperationError("Written feedback needs a feedback question.", 400);
      followUp = { type: "written_feedback", question: followQuestion };
    } else {
      const followOptions = Array.isArray(raw.options) ? raw.options.map((option) => ({ id: clean(option.id, 80), label: clean(option.label, 120) })).filter((option) => option.id && option.label) : [];
      if (!followQuestion || followOptions.length < 2) throw new ProductOperationError("A follow-up needs a question and at least two options.", 400);
      followUp = { type: "multiple_choice", question: followQuestion, options: followOptions };
    }
  }
  return { businessName, idea, question, options, followUp, allowUpdates: body.allowUpdates === true, status: "Testing" };
}
function publicPulse(pulse) {
  return { id: pulse.id, businessName: pulse.businessName, idea: pulse.idea, question: pulse.question, options: pulse.options, followUp: pulse.followUp, allowUpdates: pulse.allowUpdates, createdAt: pulse.createdAt };
}
function requireResource(record, type) {
  if (record.status !== "completed" || record.resourceType !== type || !record.resourceId) throw new ProductOperationError("Operation is still in progress.", 409);
  return record.resourceId;
}
function createProductOperations(repository) {
  return {
    async recordTelemetry(body, key) {
      if (!PRODUCT_EVENT_NAMES.includes(String(body.name))) throw new ProductOperationError("Unknown event", 400);
      const event = {
        name: String(body.name),
        pulseId: clean(body.pulseId) || null,
        sessionId: clean(body.sessionId, 100) || null,
        metadata: body.name === "powered_by_clicked" ? parseAttribution({ source: body.metadata?.source, sourcePulseId: body.pulseId }) : typeof body.metadata === "object" ? body.metadata : null
      };
      return repository.runIdempotent(idempotency(key, "record_telemetry", event), async (tx) => {
        const [saved] = await tx.insertEvents([event]);
        return { result: { ok: true }, resourceType: "event", resourceId: String(saved.id) };
      }, async (_tx, record) => {
        requireResource(record, "event");
        return { ok: true };
      });
    },
    async createPulse(body, key) {
      const input = normalizePulse(body);
      const sessionId = clean(body.sessionId, 100);
      const acquisition = parseAttribution(body.acquisition);
      const logical = { ...input, sessionId, acquisition };
      return repository.runIdempotent(idempotency(key, "create_pulse", logical), async (tx) => {
        const prior = sessionId ? await tx.countCreatedPulses(sessionId) : 0;
        const pulse = await tx.insertPulse(input);
        const base = { pulseId: pulse.id, sessionId, metadata: acquisition };
        await tx.insertEvents([{ name: "pulse_created", ...base }, { name: "pulse_published", ...base }, ...prior > 0 ? [{ name: "second_pulse_created", ...base }] : []]);
        return { result: pulse, resourceType: "pulse", resourceId: pulse.id };
      }, async (tx, record) => {
        const pulse = await tx.findPulse(requireResource(record, "pulse"));
        if (!pulse) throw new ProductOperationError("The request could not be completed.", 500);
        return pulse;
      });
    },
    async getPublicPulse(id) {
      const pulse = await repository.findPulse(id);
      if (!pulse) throw new ProductOperationError("Pulse not found", 404);
      return publicPulse(pulse);
    },
    async submitResponse(id, body, key) {
      const initialPulse = await repository.findPulse(id);
      if (!initialPulse) throw new ProductOperationError("Pulse not found", 404);
      const optionId = clean(body.optionId, 80);
      const followUpOptionId = clean(body.followUpOptionId, 80) || null;
      const written = writtenFeedbackValue(body.followUpText);
      if (!written.valid) throw new ProductOperationError("Written feedback must be 1000 characters or fewer.", 400);
      const email = initialPulse.allowUpdates ? clean(body.email, 320).toLowerCase() || null : null;
      const sessionId = clean(body.sessionId, 100);
      const normalized = { pulseId: id, optionId, followUpOptionId, followUpText: written.value, email, sessionId };
      const validate = (pulse) => {
        if (!pulse.options.some((option) => option.id === optionId)) throw new ProductOperationError("Choose a valid response.", 400);
        if (pulse.followUp && !isWrittenFollowUp(pulse.followUp) && !pulse.followUp.options.some((option) => option.id === followUpOptionId)) throw new ProductOperationError("Choose a follow-up response.", 400);
        if (isWrittenFollowUp(pulse.followUp) && followUpOptionId) throw new ProductOperationError("Written feedback does not accept response options.", 400);
        if (!isWrittenFollowUp(pulse.followUp) && written.value) throw new ProductOperationError("Written feedback is not configured for this Pulse.", 400);
        if (email && !/^\S+@\S+\.\S+$/.test(email)) throw new ProductOperationError("Enter a valid email address.", 400);
      };
      validate(initialPulse);
      return repository.runIdempotent(idempotency(key, "submit_response", normalized), async (tx) => {
        const pulse = await tx.findPulse(id);
        if (!pulse) throw new ProductOperationError("Pulse not found", 404);
        validate(pulse);
        const saved = await tx.insertResponse({ pulseId: id, optionId, followUpOptionId, followUpText: written.value, email });
        await tx.insertEvents([{ name: "response_completed", pulseId: id, sessionId }, ...email ? [{ name: "update_opt_in", pulseId: id, sessionId }] : []]);
        return { result: { ok: true }, resourceType: "response", resourceId: String(saved.id) };
      }, async (_tx, record) => {
        requireResource(record, "response");
        return { ok: true };
      });
    },
    async getCreatorResults(id, creatorKey) {
      const pulse = await repository.findOwnedPulse(id, creatorKey);
      if (!pulse) throw new ProductOperationError("Results access denied", 403);
      return repository.transaction(async (tx) => {
        const rows = await tx.listResponses(id);
        const total = rows.length;
        const aggregate = (options, field) => options.map((option) => {
          const optionCount = rows.filter((row) => row[field] === option.id).length;
          return { ...option, count: optionCount, percentage: total ? Math.round(optionCount / total * 100) : 0 };
        });
        const { creatorKey: _creatorKey, ...safePulse } = pulse;
        void _creatorKey;
        return { pulse: safePulse, total, options: aggregate(pulse.options, "optionId"), followUp: pulse.followUp && !isWrittenFollowUp(pulse.followUp) ? aggregate(pulse.followUp.options, "followUpOptionId") : [], writtenFeedback: collectWrittenFeedback(rows), updateOptIns: rows.filter((row) => row.email).length };
      });
    },
    async updateLifecycle(id, body) {
      const status = clean(body.status, 30);
      const creatorKey = clean(body.key, 80);
      if (!PRODUCT_STATUSES.includes(status) || !await repository.findOwnedPulse(id, creatorKey)) throw new ProductOperationError("Invalid status or access denied", 403);
      await repository.transaction((tx) => tx.updateStatus(id, status));
      return { status };
    },
    async submitCreatorFeedback(id, body, key) {
      const creatorKey = clean(body.key, 80);
      if (!await repository.findOwnedPulse(id, creatorKey)) throw new ProductOperationError("Access denied", 403);
      const values = { decision: clean(body.decision, 1e3), useful: clean(body.useful, 1e3), affectedPlan: clean(body.affectedPlan, 1e3), useAgain: clean(body.useAgain, 1e3), worthPaying: clean(body.worthPaying, 1e3) };
      if (Object.values(values).some((value) => !value)) throw new ProductOperationError("Please answer every feedback question.", 400);
      return repository.runIdempotent(idempotency(key, "submit_creator_feedback", { pulseId: id, ...values }), async (tx) => {
        if (!await tx.findOwnedPulse(id, creatorKey)) throw new ProductOperationError("Access denied", 403);
        const saved = await tx.insertFeedback({ pulseId: id, ...values });
        return { result: { ok: true }, resourceType: "feedback", resourceId: String(saved.id) };
      }, async (tx, record) => {
        if (!await tx.findOwnedPulse(id, creatorKey)) throw new ProductOperationError("Access denied", 403);
        requireResource(record, "feedback");
        return { ok: true };
      });
    }
  };
}

// db/productOperationRepository.ts
function adapter(database) {
  return {
    async countCreatedPulses(sessionId) {
      const [row] = await database.select({ value: count4() }).from(events).where(and3(eq4(events.sessionId, sessionId), eq4(events.name, "pulse_created")));
      return row.value;
    },
    async insertPulse(input) {
      const [row] = await database.insert(pulses).values(input).returning();
      return row;
    },
    async findPulse(id) {
      const [row] = await database.select().from(pulses).where(eq4(pulses.id, id)).limit(1);
      return row ?? null;
    },
    async findOwnedPulse(id, creatorKey) {
      const [row] = await database.select().from(pulses).where(and3(eq4(pulses.id, id), eq4(pulses.creatorKey, creatorKey))).limit(1);
      return row ?? null;
    },
    async insertEvents(input) {
      return database.insert(events).values(input).returning({ id: events.id });
    },
    async insertResponse(input) {
      const [row] = await database.insert(responses).values(input).returning({ id: responses.id });
      return row;
    },
    async listResponses(pulseId) {
      return database.select().from(responses).where(eq4(responses.pulseId, pulseId));
    },
    async updateStatus(id, status) {
      await database.update(pulses).set({ status }).where(eq4(pulses.id, id));
    },
    async insertFeedback(input) {
      const [row] = await database.insert(feedback).values(input).returning({ id: feedback.id });
      return row;
    }
  };
}
var productOperationRepository = {
  async findPulse(id) {
    return adapter(db).findPulse(id);
  },
  async findOwnedPulse(id, creatorKey) {
    return adapter(db).findOwnedPulse(id, creatorKey);
  },
  async transaction(operation) {
    return db.transaction((transaction) => operation(adapter(transaction)));
  },
  async runIdempotent(request, execute, replay) {
    return db.transaction(async (transaction) => {
      const database = transaction;
      const tx = adapter(database);
      const [claim] = await database.insert(productOperationIdempotency).values(request).onConflictDoNothing().returning();
      if (!claim) {
        const [existing] = await database.select().from(productOperationIdempotency).where(and3(eq4(productOperationIdempotency.operationScope, request.operationScope), eq4(productOperationIdempotency.idempotencyKeyHash, request.idempotencyKeyHash))).limit(1);
        if (!existing || existing.requestFingerprint !== request.requestFingerprint) throw new ProductOperationError("Idempotency key conflicts with a different request.", 409);
        const record = { requestFingerprint: existing.requestFingerprint, status: existing.status, resourceType: existing.resourceType, resourceId: existing.resourceId };
        if (record.status !== "completed") throw new ProductOperationError("Operation is still in progress.", 409);
        return { value: await replay(tx, record), replayed: true };
      }
      const completed = await execute(tx);
      await database.update(productOperationIdempotency).set({ status: "completed", resourceType: completed.resourceType ?? null, resourceId: completed.resourceId ?? null, completedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq4(productOperationIdempotency.id, claim.id));
      return { value: completed.result, replayed: false };
    });
  }
};

// server/productServiceAuth.ts
import { createHash as createHash3, timingSafeEqual as timingSafeEqual2 } from "node:crypto";
var digest2 = (value) => createHash3("sha256").update(value, "utf8").digest();
function hasProductServiceCredential(request, configuredSecret) {
  const supplied = request.headers.get("authorization");
  if (!configuredSecret || !supplied?.startsWith("Bearer ")) return false;
  const credential = supplied.slice(7);
  if (!credential) return false;
  return timingSafeEqual2(digest2(configuredSecret), digest2(credential));
}

// server/productServiceHandler.ts
var json2 = (body, status = 200) => Response.json(body, { status });
var error = (message, status) => json2({ error: message }, status);
var idempotencyKey = (request) => request.headers.get("idempotency-key")?.trim() ?? "";
function createProductServiceHandler({ operations, secret }) {
  return async (request) => {
    if (!hasProductServiceCredential(request, secret())) return error("Authentication failed.", 401);
    try {
      const parts = new URL(request.url).pathname.replace(/^\/api\/product-service\/?/, "").split("/").filter(Boolean);
      if (request.method === "POST" && parts[0] === "events") {
        await operations.recordTelemetry(await request.json(), idempotencyKey(request));
        return json2({ ok: true }, 201);
      }
      if (request.method === "POST" && parts[0] === "pulses" && parts.length === 1) {
        const result = await operations.createPulse(await request.json(), idempotencyKey(request));
        return json2(result.value, 201);
      }
      const id = parts[1];
      if (!id) return error("Not found", 404);
      if (request.method === "GET" && parts[0] === "pulses" && parts.length === 2) return json2(await operations.getPublicPulse(id));
      if (request.method === "POST" && parts[2] === "responses") {
        await operations.submitResponse(id, await request.json(), idempotencyKey(request));
        return json2({ ok: true }, 201);
      }
      if (request.method === "GET" && parts[2] === "results") return json2(await operations.getCreatorResults(id, request.headers.get("x-creator-key")?.trim().slice(0, 80) ?? ""));
      if (request.method === "PATCH" && parts[2] === "status") return json2(await operations.updateLifecycle(id, await request.json()));
      if (request.method === "POST" && parts[2] === "feedback") {
        await operations.submitCreatorFeedback(id, await request.json(), idempotencyKey(request));
        return json2({ ok: true }, 201);
      }
      return error("Not found", 404);
    } catch (caught) {
      if (caught instanceof ProductOperationError) return error(caught.message, caught.status);
      console.error("Product Service request failed");
      return error("The request could not be completed.", 500);
    }
  };
}

// server/prospectDiscoveryProvider.ts
var UnconfiguredPublicWebDiscoveryProvider = class {
  id = "unconfigured_public_web";
  async discover(criteria, signal) {
    void criteria;
    void signal;
    throw new DiscoveryProviderUnavailableError();
  }
};

// server/tavilyProspectDiscoveryProvider.ts
var TAVILY_SEARCH_ENDPOINT = "https://api.tavily.com/search";
var REQUEST_TIMEOUT_MS = 7e3;
var MAX_RESPONSE_BYTES = 1e6;
var MAX_UPSTREAM_RESULTS = 20;
var PREFERRED_EXCERPT_LENGTH = 360;
var DIRECTORY_HOSTS = ["yelp.com", "tripadvisor.com", "yell.com", "bbb.org", "chamberofcommerce.com", "yellowpages.com"];
var SOCIAL_HOSTS = ["facebook.com", "instagram.com", "linkedin.com"];
var UNSUPPORTED_HOSTS = ["tavily.com", "google.com", "bing.com", "yahoo.com", "duckduckgo.com", "x.com", "twitter.com", "youtube.com"];
function hostMatches(hostname, domain) {
  return hostname === domain || hostname.endsWith(`.${domain}`);
}
function classifySource(sourceUrl) {
  const url = new URL(sourceUrl);
  const hostname = url.hostname.toLowerCase();
  if (UNSUPPORTED_HOSTS.some((domain) => hostMatches(hostname, domain))) return null;
  if (DIRECTORY_HOSTS.some((domain) => hostMatches(hostname, domain))) return "public_business_directory";
  if (SOCIAL_HOSTS.some((domain) => hostMatches(hostname, domain))) return "public_social_business_page";
  return "business_website";
}
function businessNameFromTitle(title) {
  const name = title.split(/\s[|–—-]\s/)[0]?.trim();
  if (!name || name.length > 240) return null;
  return name;
}
function likelyOfficialWebsite(sourceUrl, businessName, email) {
  const hostname = new URL(sourceUrl).hostname.toLowerCase().replace(/^www\./, "");
  const emailDomain = email.slice(email.lastIndexOf("@") + 1).toLowerCase();
  if (hostMatches(hostname, emailDomain) || hostMatches(emailDomain, hostname)) return true;
  const compactHost = hostname.replace(/[^a-z0-9]/g, "");
  return businessName.toLowerCase().split(/[^a-z0-9]+/).some((token) => token.length >= 4 && compactHost.includes(token));
}
function extractEmails(content) {
  const matches = content.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+/gi) ?? [];
  return [...new Map(matches.filter((email) => email.length <= 320).map((email) => [email.toLocaleLowerCase("en-US"), email])).values()];
}
function excerptAround(content, email) {
  const index2 = content.toLocaleLowerCase("en-US").indexOf(email.toLocaleLowerCase("en-US"));
  if (index2 < 0) return null;
  const budget = Math.min(PREFERRED_EXCERPT_LENGTH, MAX_EVIDENCE_EXCERPT);
  const start = Math.max(0, index2 - Math.floor((budget - email.length) / 2));
  const end = Math.min(content.length, start + budget);
  return content.slice(start, end).trim();
}
async function readBoundedJson(response2) {
  if (!response2.body) throw new DiscoveryProviderUnavailableError();
  const reader = response2.body.getReader();
  const decoder = new TextDecoder();
  let total = 0;
  let text2 = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_RESPONSE_BYTES) {
        await reader.cancel();
        throw new DiscoveryProviderUnavailableError();
      }
      text2 += decoder.decode(value, { stream: true });
    }
    text2 += decoder.decode();
    const parsed = JSON.parse(text2);
    if (!parsed || typeof parsed !== "object") throw new Error("malformed");
    return parsed;
  } catch (error2) {
    if (error2 instanceof DiscoveryProviderUnavailableError) throw error2;
    throw new DiscoveryProviderUnavailableError();
  }
}
function combineAbortSignals(signal, timeoutMs) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (signal.aborted) abort();
  else signal.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(abort, timeoutMs);
  return {
    signal: controller.signal,
    dispose: () => {
      clearTimeout(timer);
      signal.removeEventListener("abort", abort);
    }
  };
}
var TavilyProspectDiscoveryProvider = class {
  constructor(options) {
    this.options = options;
  }
  options;
  id = "tavily_public_search";
  async discover(criteria, signal) {
    const apiKey = this.options.apiKey();
    if (!apiKey) throw new DiscoveryProviderUnavailableError();
    const upstreamLimit = Math.min(MAX_UPSTREAM_RESULTS, Math.max(criteria.maxResults, criteria.maxResults * 3));
    const combined = combineAbortSignals(signal, this.options.timeoutMs ?? REQUEST_TIMEOUT_MS);
    try {
      const response2 = await (this.options.fetch ?? fetch)(TAVILY_SEARCH_ENDPOINT, {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          query: `${criteria.category} businesses in ${criteria.location} official website contact email`,
          search_depth: "advanced",
          max_results: upstreamLimit,
          include_answer: false,
          include_images: false,
          include_raw_content: "text"
        }),
        signal: combined.signal
      });
      if (!response2.ok) throw new DiscoveryProviderUnavailableError();
      const payload = await readBoundedJson(response2);
      if (!Array.isArray(payload.results)) throw new DiscoveryProviderUnavailableError();
      const candidates = [];
      const seenEmails = /* @__PURE__ */ new Set();
      for (const rawResult of payload.results.slice(0, upstreamLimit)) {
        if (candidates.length >= criteria.maxResults) break;
        if (!rawResult || typeof rawResult !== "object" || typeof rawResult.title !== "string" || typeof rawResult.url !== "string" || typeof rawResult.raw_content !== "string") continue;
        if (!isSafePublicUrl(rawResult.url) || rawResult.raw_content.length > MAX_RESPONSE_BYTES) continue;
        const sourceType = classifySource(rawResult.url);
        const businessName = businessNameFromTitle(rawResult.title);
        if (!sourceType || !businessName) continue;
        const email = extractEmails(rawResult.raw_content).find((value) => !seenEmails.has(value.toLocaleLowerCase("en-US")));
        if (!email) continue;
        if (!rawResult.raw_content.toLocaleLowerCase("en-US").includes(businessName.toLocaleLowerCase("en-US"))) continue;
        if (sourceType === "business_website" && !likelyOfficialWebsite(rawResult.url, businessName, email)) continue;
        const observedText = excerptAround(rawResult.raw_content, email);
        if (!observedText) continue;
        seenEmails.add(email.toLocaleLowerCase("en-US"));
        const contentLower = rawResult.raw_content.toLocaleLowerCase("en-US");
        candidates.push({
          businessName,
          industry: contentLower.includes(criteria.category.toLocaleLowerCase("en-US")) ? criteria.category : null,
          locationText: contentLower.includes(criteria.location.toLocaleLowerCase("en-US")) ? criteria.location : null,
          websiteUrl: sourceType === "business_website" ? rawResult.url : null,
          sourceType,
          sourceUrl: rawResult.url,
          sourceObservedAt: (this.options.now ?? (() => /* @__PURE__ */ new Date()))().toISOString(),
          evidenceNote: "Retrieved public source content identifies the business and displays the exact public email address.",
          potentialUseCase: null,
          personalizationContext: null,
          personalizationEvidence: null,
          publicEmailEvidence: { email, sourceUrl: rawResult.url, observedText }
        });
      }
      return candidates;
    } catch {
      throw new DiscoveryProviderUnavailableError();
    } finally {
      combined.dispose();
    }
  }
};

// netlify/growth-functions/api.mts
var tavilyDiscoveryProvider = new TavilyProspectDiscoveryProvider({ apiKey: () => Netlify.env.get("TAVILY_API_KEY") });
var unconfiguredDiscoveryProvider = new UnconfiguredPublicWebDiscoveryProvider();
var discoveryProvider = {
  get id() {
    return Netlify.env.has("TAVILY_API_KEY") ? tavilyDiscoveryProvider.id : unconfiguredDiscoveryProvider.id;
  },
  discover(criteria, signal) {
    const selected = Netlify.env.has("TAVILY_API_KEY") ? tavilyDiscoveryProvider : unconfiguredDiscoveryProvider;
    return selected.discover(criteria, signal);
  }
};
var operatorAuth = createOperatorAuthHandler({ store: operatorStore, secret: () => Netlify.env.get("LIVING_PULSE_OPERATOR_SECRET") });
var operatorConsole = createOperatorConsoleHandler({
  authenticated: (request) => hasOperatorSession(request, operatorStore),
  repository: acquisitionConsoleRepository,
  services: { createProspect: createProspect2, qualifyProspect, rejectProspect, suppressProspect, queueProspect },
  discoveryProvider,
  prospectExistsByEmail: async (email) => Boolean(await prospectStore.findProspectByEmail(email))
});
var api_default = async (request, context) => {
  if (new URL(request.url).pathname.startsWith("/api/product-service/")) {
    return createProductServiceHandler({
      operations: createProductOperations(productOperationRepository),
      secret: () => Netlify.env.get("LIVING_PULSE_PRODUCT_SERVICE_SECRET")
    })(request);
  }
  const parts = new URL(request.url).pathname.replace(/^\/api\/operator\/?/, "").split("/").filter(Boolean);
  if (["acquisition", "prospects", "outreach", "suppressions"].includes(parts[0])) return operatorConsole(request);
  return operatorAuth(request, context.ip);
};
var config = { path: ["/api/operator/*", "/api/product-service/*"] };
export {
  config,
  api_default as default
};
